-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 30, 2022 at 11:01 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chatapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `msg_id` int(11) NOT NULL,
  `incoming_msg_id` int(255) NOT NULL,
  `outgoing_msg_id` int(255) NOT NULL,
  `msg` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`msg_id`, `incoming_msg_id`, `outgoing_msg_id`, `msg`) VALUES
(1, 1170374539, 1467812794, 'Hii Bro'),
(2, 1467812794, 1170374539, 'Hello Bro'),
(3, 1235552797, 1259291474, 'Hiii Aman'),
(4, 1259291474, 1235552797, 'Hiii Kuku'),
(5, 1259291474, 1235552797, 'How are you ?'),
(6, 1235552797, 1259291474, 'All good'),
(7, 1235552797, 1259291474, 'what about you?'),
(8, 1259291474, 1235552797, 'I am good '),
(9, 1259291474, 1235552797, 'Are you free this saturday?'),
(10, 1235552797, 1259291474, 'No I have to prepare for my technical interview'),
(11, 1235552797, 713700627, 'hii'),
(12, 1259291474, 1235552797, 'hiiii'),
(13, 1235552797, 1259291474, 'hlo'),
(14, 1235552797, 1259291474, 'hello xavier'),
(15, 1235552797, 1259291474, 'hiii kuku');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `unique_id` int(255) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `unique_id`, `fname`, `lname`, `email`, `password`, `img`, `status`) VALUES
(1, 1170374539, 'Aman', 'Yadav', 'aman@gmail.com', 'ccda1683d8c97f8f2dff2ea7d649b42c', '1656528995IMG_20200925_165729_778.jpg', 'Offline now'),
(2, 1467812794, 'Ankush', 'Mehta', 'ankush@gmail.com', '3a0135f9157447e16da5c17863f1531c', '1656529063WhatsApp Image 2022-06-25 at 1.15.06 AM.jpeg', 'Offline now'),
(3, 1235552797, 'Aman', 'Xavier', 'amanx@gmail.com', '45d7379ed0e9f1baaa973f7e1b69543f', '1656529375IMG_20200925_165729_778.jpg', 'Offline now'),
(5, 1517973098, 'Abhishek', 'Khanna', 'abhishek@gmail.com', 'f589a6959f3e04037eb2b3eb0ff726ac', '1656529598WhatsApp Image 2022-06-30 at 12.35.14 AM.jpeg', 'Offline now'),
(6, 202846187, 'Ankush', 'Mehta', 'ankush123@gmail.com', '3a0135f9157447e16da5c17863f1531c', '1656529664WhatsApp Image 2022-06-25 at 1.15.06 AM.jpeg', 'Offline now'),
(7, 1095165855, 'Dony', 'Chauhan', 'dony@gmail.com', '77ee6d05b23e742e2aca3fd602f4c599', '1656529703WhatsApp Image 2022-06-24 at 8.02.20 PM.jpeg', 'Offline now'),
(8, 1259291474, 'Savinder', 'Jaglan', 'savinder@gmail.com', '81c24a7b6488b75222eebcb7e0b50849', '1656529949WhatsApp Image 2022-06-30 at 12.41.01 AM.jpeg', 'Active now'),
(9, 713700627, 'Nitin', 'Bhalla', 'nitin@gmail.com', 'b585c4415b1fe50f2c31fa1698b271b7', '16565704944509705.jpg', 'Offline now');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`msg_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `msg_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
